#!/bin/sh

sec_path="tool_EMMC_bin/"

case "$1" in
	clean)
		echo make clean
		make mrproper
		;;
	*)
		rm  u-boot.bin  myuboot_emmc.bin
		
		
		gcc add_padding.c -o padding
        chmod 777 padding
        cp  ../u-boot-2013.01/u-boot.bin   ./
		./padding
		
		cat E4412_N.bl1.SCP2G.bin bl2.bin all00_padding.bin u-boot.bin tzsw_SMDK4412_SCP_2GB.bin > myuboot_emmc.bin

		echo 
		echo 
		;;
		
esac
