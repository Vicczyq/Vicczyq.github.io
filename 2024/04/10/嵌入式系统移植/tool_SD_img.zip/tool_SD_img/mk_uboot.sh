# full size: 15k(bl1) + 14k(bl2) + 2k(pad) + 328k(u-boot) + 156k(tz) = 515k

cp  ../u-boot-2013.01/u-boot.bin   ./

./add_padding_uboot_328 u-boot.bin # uboot : 0x43e0_0000

cat E4412_N.bl1.SCP2G.bin bl2.bin all00_padding.bin u-boot.bin tzsw_SMDK4412_SCP_2GB.bin > myuboot.bin

dd iflag=dsync oflag=dsync if=myuboot.bin of=myuboot_sd.img seek=1   #在uboot镜像前加512字节的0， 间接的让uboot烧到第二块开始
